﻿//Colby Holmes 
//Project 2 Base

#include <stdio.h>
#include <string.h>

int main(){

  char fname[256];
  printf("Please enter the filename to be tested: ");
  scanf("%s", fname);

  FILE* fp = fopen(fname, "r");

//store up to 50 of each item
  char pids[50][20]; //each pid up to 20 chars
  int arrTime[50];
  int runTime[50];
  int priority[50];

  int i = 0;
  char buffer[20];

  while (fscanf(fp, "%s", buffer) != EOF) {//while not the end of the file

    strcpy(pids[i], buffer);//copy buffer to pids
    //scan rest of data from line
    fscanf(fp, "%d", &(arrTime[i]));
    fscanf(fp, "%d", &(runTime[i]));
    fscanf(fp, "%d", &(priority[i]));

    //increment i and check next line
    i++;
  }

  //close file
  fclose(fp);

  //test print the arrays
  int j;
  for (j = 0; j < i; j++) {
    printf("%s %d %d %d\n", pids[j], arrTime[j], runTime[j], priority[j]);
  }

  return 0;
}