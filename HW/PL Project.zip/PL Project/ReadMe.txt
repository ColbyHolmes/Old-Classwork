Colby Holmes
CSCE 4430
Programming Languages
Final Project

Everything should compile and run as per the instructions.
I used BS4 for the python code.
Funfact: I definitely spent more time getting and IDE with Python and BS4 installed
than I did actually coding.

Anyways, hope you have a lovely break!
Happy Holidays and all that Jazz!