// Token class definition
// Token is a class to represent lexical tokens in the mPHP programming 
// language, described in Programming Languages: Principles and Paradigms, 
// 2nd ed., by Allen B. Tucker and Robert E. Noonan, McGraw Hill, 2007.

public class Token {

  private TokenClass symbol;	// current token
  private String lexeme;	// lexeme

  public Token () { }

  public Token (TokenClass symbol) {
    this (symbol, null);
  }

  public Token (TokenClass symbol, String lexeme) {
    this . symbol = symbol;
    this . lexeme  = lexeme;
  }

  public TokenClass symbol () { return symbol; }

  public String lexeme () { return lexeme; }

  public String toString () {
    switch (symbol) {
      case BOOL :      return "(keyword, bool) ";
      case ELSE :      return "(keyword, else) ";
      case IF :        return "(keyword, if) ";
      case INT :       return "(keyword, int) ";
      case MAIN :      return "(keyword, main) ";
      case WHILE :     return "(keyword, while) ";
      case COMMA :     return "(punctuation, ,) ";
      case SEMICOLON : return "(punctuation, ;) ";
      case LBRACE :    return "(punctuation, {) ";
      case RBRACE :    return "(punctuation, }) ";
      case LPAREN :    return "(operator, () ";
      case RPAREN :    return "(operator, )) ";
      case LBRACK :    return "(operator, [) ";
      case RBRACK :    return "(operator, ]) ";
      case ASSIGN :    return "(operator, =) ";
      case OR :        return "(operator, ||) ";
      case AND :       return "(operator, &&) ";
      case PLUS :      return "(operator, +) ";
      case MINUS :     return "(operator, -) ";
      case TIMES :     return "(operator, *) ";
      case SLASH :     return "(operator, /) ";
      case MOD :       return "(operator, %) ";
      case EQ :        return "(operator, ==) ";
      case NE :        return "(operator, !=) ";
      case LT :        return "(operator, <) ";
      case LE :        return "(operator, <=) ";
      case GT :        return "(operator, >) ";
      case GE :        return "(operator, >=) ";
      case NOT :       return "(operator, !) ";
      case ID :        return "(identifier, " + lexeme + ") ";
      case INTEGER :   return "(integer, " + lexeme + ") ";
      case BOOLEAN :   return "(boolean, " + lexeme + ") ";
      case STARTP :    return "(keyword, <?php) ";
      case ENDP :      return "(keyword, ?>) ";
      case FUNCTION :  return "(keyword, function) ";
      case RETURN :    return "(keyword, return) ";
      case FOREACH :   return "(keyword, foreach) ";
      case PRINT :     return "(keyword, print) ";
      case AS :        return "(keyword, as) ";
      case APUSH :     return "(keyword, array_push) ";
      case APOP :      return "(keyword, array_pop) ";
      case ARRAY :     return "(keyword, array) ";
      case NULL :      return "(identifier, NULL) ";

      default : 
	ErrorMessage . print (0, "Unrecognized token");
        return null;
    }
  }

}
