Colby Holmes

Programming Languages

Program 1 (HW2)

mPHP lexical analyzer

Due 9/30/16


To compile yourself:

"jflex mphp.jflex"

"javac *.java"


To run:

"java mphpLex < [testfile]"



Files included:

mphp.jflex

mphpLexer.java

Token.java

TokenClass.java

ErrorMessage.java

mphpLex.java

(This readme file)