// TokenClass enumeration definition
// TokenClass is an enumeration to represent lexical token classes in the 
// mPHP programming language.

public enum TokenClass {
  EOF, 
  // keywords
  BOOL, ELSE, IF, INT, MAIN, WHILE, STARTP, ENDP, FUNCTION, RETURN,
  FOREACH, PRINT, AS, APUSH, APOP, ARRAY,
  // punctuation
  COMMA, SEMICOLON, LBRACE, RBRACE,
  // operators
  LPAREN, RPAREN, LBRACK, RBRACK, ASSIGN, OR, AND, EQ, NE, LT, LE, GT, GE, 
  PLUS, MINUS, TIMES, SLASH, MOD, NOT,
  // ids and literals
  ID, INTEGER, BOOLEAN, NULL
}
