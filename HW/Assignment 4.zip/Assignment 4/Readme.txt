Colby Holmes
Assignment 4
Python Coding

All of the programs should operate just as the instructions directed.
I don't think I was supposed to provide the test files...