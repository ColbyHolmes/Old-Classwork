Colby Holmes
Homework 2

Sorry if handwriting the answers and submitting pictures isn't optimal.
Trying to draw trees of that size on the computer is overly complicated and time
consuming. I hope you can read the answers well. If not, I've got the physical
copies of the work and can submit that or try and take better pictures/ get
access to a scanner.