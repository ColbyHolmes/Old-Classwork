Colby Holmes
Homework 3

I had a lot of trouble with Problem 1. (Thank goodness I dont
plan on being a LISP programmer...) I never got it to display errors
correctly, and realized after i spent too much time coding that it 
accepts strings, not lists. So instead of "(romanToDecimal '(C D V))",
it accepts "(romanToDecimal "CDV")". That's entirely my fault, but I 
don't have the time to correct it.

Luckily, I did the delete function first, and had much less trouble with it.
So hopefully I get full points on that one.