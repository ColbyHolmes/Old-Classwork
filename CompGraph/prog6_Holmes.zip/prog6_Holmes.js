﻿// prog6_Holmes.js
//Colby Holmes
//5/3/17

//Description:
//This program creates displays a two-segment piecewise cubic (degree-3) planar Bezier curve
// with continuous tangent vector at every point
//
// control points P0, P1, P2, and P3 define the first segment
// P3, P4, P5, and P6 define the second segment
//
// with P2, P3, and P4 collinear



//Oye...
//This program has been a lot of work, and proved very difficult,
//despite hours of studying the material and coding tutorials.
//I also was on the back end of coding when I noticed
//I needed to write it in a matrix format. After the amount of work
//I put in already, I will not be changing to that form.


function main() {
    //sets default curve and allows user to drag around
    var webgl = new sCurve("webgl", .5, [.1, .1, .3, .5, .7, .9, .9],
  [.1, .8, .8, .5, .2, .2, .9]);
}


function sCurve(canvas1id, scale, ptX, ptY) {

    var canvas, ctx, w, h, h1, d, d2, dragId = -1;
    var n = ptX.length, n1 = n + 1;
    var Px = new Float64Array(ptX),
        Py = new Float64Array(ptY);
    canvas = document.getElementById(canvas1id);
    ctx = canvas.getContext("2d");

    //listeners for dragging the points
    canvas.addEventListener('mousemove', drag, false);
    canvas.addEventListener('mousedown', start_drag, false);
    canvas.addEventListener('mouseup', stop_drag, false);

    //allows user to zoom in or out
    window.addEventListener('resize', resize, false);
    document.addEventListener('keydown', function (event) {
        if (event.keyCode == 38) {
            scale += .1;
            resize();
        }
        else if (event.keyCode == 40) {
            if (scale > 0) {
                scale -= .1;
                resize();
            }
        }
    });
    //set canvas size and calculate key variables
    resize();


    function drawSpline() {
        var step = 1 / w, t = step;
        var Pxi = new Float64Array(n), Pyi = new Float64Array(n);
        var scPx = new Float64Array(n), scPy = new Float64Array(n);
        var X, Y;

        //draws the line segments
        ctx.clearRect(0, 0, w, h);
        ctx.lineWidth = d;
        ctx.strokeStyle = "#000000";
        for (var i = 0; i < n; i++) {
            X = scPx[i] = Px[i] * w;
            Y = scPy[i] = Py[i] * h;
            ctx.strokeRect(X - d, h1 - Y - d, d2, d2);
        }
        //if there is more than one line segment
        if (n > 2) {
            ctx.beginPath(); ctx.moveTo(scPx[0], h1 - scPy[0]);
            for (var i = 1; i < n; i++)
                ctx.lineTo(scPx[i], h1 - scPy[i]);
            ctx.stroke();
        }

        //draws the spline
        ctx.lineWidth = d2;
        ctx.strokeStyle = "#f00000";
        ctx.beginPath(); ctx.moveTo(scPx[0], h1 - scPy[0]);
        for (var k = 1; k < w; k++) {
            Pxi.set(scPx);
            Pyi.set(scPy);
            for (var j = 3; j > 0; j--)
                for (var i = 0; i < j; i++) {
                    Pxi[i] = (1 - t) * Pxi[i] + t * Pxi[i + 1];
                    Pyi[i] = (1 - t) * Pyi[i] + t * Pyi[i + 1];
                }
            ctx.lineTo(Pxi[0], h1 - Pyi[0]);
            t += step;
        }
        ctx.stroke();

        ctx.lineWidth = d2;
        ctx.strokeStyle = "#f00000";
        ctx.beginPath();
        for (var k = 1; k < w; k++) {
            Pxi.set(scPx);
            Pyi.set(scPy);
            for (var j = n-1; j > 3; j--)
                for (var i = 0; i < j; i++) {
                    Pxi[i] = (1 - t) * Pxi[i] + t * Pxi[i + 1];
                    Pyi[i] = (1 - t) * Pyi[i] + t * Pyi[i + 1];
                }
            ctx.lineTo(Pxi[3], h1 - Pyi[3]);
            t -= step;
        }
        ctx.stroke();
    }

    //can be used to change the size of the canvas
    //calculates key variables according to the canvas size
    function resize() {
        h = w = Math.round(window.innerWidth * scale);
        h1 = h - 1;
        d = Math.max(1, Math.round(w / 250)); d2 = d + d;
        canvas.width = w; canvas.height = h;
        drawSpline();
    }

    //allows the user to drag points around
    function drag(ev) {
        if (dragId < 0) return;
        var c = getXY(ev);
        var difX = c[0] - Px[dragId]; var difY = c[1] - Py[dragId];
        Px[dragId] = c[0]; Py[dragId] = c[1];

        //keep p2-p4 colinear
        if (dragId == 2) {
            Px[4] = Px[4] - difX;
            Py[4] = Py[4] - difY;
        }
        else if (dragId == 4) {
            Px[2] = Px[2] - difX;
            Py[2] = Py[2] - difY;
        }
        else if (dragId == 3) {
            Px[4] = Px[4] + difX;
            Py[4] = Py[4] + difY;

            Px[2] = Px[2] + difX;
            Py[2] = Py[2] + difY;
        }

        drawSpline();
        ev.preventDefault();
    }

    //allows the user to drag points around
    function start_drag(ev) {
        var c = getXY(ev);
        //grabs the closest point
        var Rmin = 2, r2, xi, yi;
        for (var i = 0; i < n; i++) {
            xi = (c[0] - Px[i]); yi = (c[1] - Py[i]);
            r2 = xi * xi + yi * yi;
            if (r2 < Rmin) { dragId = i; Rmin = r2; }
        }

        var difX = c[0] - Px[dragId]; var difY = c[1] - Py[dragId];
        Px[dragId] = c[0]; Py[dragId] = c[1];

        //keep p2-p4 colinear
        if (dragId == 2) {
            Px[4] = Px[4] - difX;
            Py[4] = Py[4] - difY;
        }
        else if (dragId == 4) {
            Px[2] = Px[2] - difX;
            Py[2] = Py[2] - difY;
        }
        else if (dragId == 3) {
            Px[4] = Px[4] + difX;
            Py[4] = Py[4] + difY;

            Px[2] = Px[2] + difX;
            Py[2] = Py[2] + difY;
        }

        drawSpline();
        ev.preventDefault();
    }

    //stop dragging point arround
    function stop_drag(ev) {
        dragId = -1;
        ev.preventDefault();
    }

    //gets the mouse position for dragging points
    function getXY(ev) {
        if (!ev.clientX) ev = ev.touches[0];
        var rect = canvas.getBoundingClientRect();
        var x = (ev.clientX - rect.left) / w,
            y = (h1 - (ev.clientY - rect.top)) / h;
        return [x, y];
    }
} // end Bezier